from moderngl_window.context.tk.window import Window  # noqa
from moderngl_window.context.tk.keys import Keys  # noqa
